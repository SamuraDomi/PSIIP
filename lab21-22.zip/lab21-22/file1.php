<?php
    $var1 = "Hello";
    echo $var1;
?>
