<?php
    $var2 = "World";
    echo $var2;
?>
