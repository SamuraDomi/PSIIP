function calculateF(t) {
        var numerator = -t + Math.sqrt(7 + t);
        var denominator = 8 - Math.abs(t);
        var f = numerator / denominator;
        return f;
    }