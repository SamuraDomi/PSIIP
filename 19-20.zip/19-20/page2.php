<?php
session_start(); // Начало сессии

// Проверяем наличие сессионных переменных
if (isset($_SESSION['email']) && isset($_SESSION['message'])) {
    $email = $_SESSION['email'];
    $message = $_SESSION['message'];
} else {
    // Если сессионные переменные не установлены, перенаправляем на страницу 1
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Страница 2</title>
</head>
<body>
    <h2>Данные из сессии</h2>
    <p><strong>Email:</strong> <?php echo $email; ?></p>
    <p><strong>Сообщение:</strong> <?php echo $message; ?></p>

    <?php
    // Выводим имя и значение идентификатора сессии
    echo "Имя сессии: " . session_name() . "<br>";
    echo "Значение сессии: " . session_id() . "<br>";
    ?>
</body>
</html>
