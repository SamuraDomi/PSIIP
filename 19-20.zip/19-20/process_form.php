<?php
session_start(); // Начало сессии

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name']; // Получаем имя из формы
    $email = $_POST['email']; // Получаем email из формы
    $message = $_POST['message']; // Получаем сообщение из формы

    // Сохраняем данные в сессионных переменных
    $_SESSION['email'] = $email;
    $_SESSION['message'] = $message;

    // Перенаправляем на страницу 2
    header("Location: page2.php");
    exit();
}
?>
