
function saveToLocalStorage() {
    // Получаем форму по её id
    var form = document.getElementById('feedbackForm');

    // Создаем объект FormData для удобной работы с данными формы
    var formData = new FormData(form);

    // Создаем объект для хранения данных
    var formDataObject = {};

    // Итерируем по парам "ключ-значение" в объекте FormData и добавляем их в объект
    formData.forEach(function(value, key){
        formDataObject[key] = value;
    });

    // Преобразуем объект в JSON-строку и сохраняем в localStorage
    localStorage.setItem('formData', JSON.stringify(formDataObject));

    // Вызываем функцию для вывода данных на экран
    showDataFromLocalStorage();
}

function showDataFromLocalStorage() {
    // Получаем сохраненные данные из localStorage
    var savedData = localStorage.getItem('formData');

    // Если данные есть, преобразуем JSON-строку в объект
    if (savedData) {
        savedData = JSON.parse(savedData);

        // Создаем строку для вывода данных
        var output = 'Сохраненные данные из localStorage:\n';

        // Итерируем по свойствам объекта и добавляем их в строку
        for (var key in savedData) {
            output += key + ': ' + savedData[key] + '\n';
        }

        // Выводим данные на странице
        document.getElementById('formDataOutput').innerText = output;
    } else {
        // Если данных нет, выводим сообщение
        document.getElementById('formDataOutput').innerText = 'Нет сохраненных данных в localStorage.';
    }
}

showDataFromLocalStorage();

function validateAndSave() {
    validateField('name', /[A-Za-zА-Яа-яЁё\s]+/, 'Введите ваше имя');
    validateField('email', /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Введите корректный адрес электронной почты');
    validateField('subject', /.+/, 'Введите тему сообщения');
    validateField('message', /.+/, 'Введите текст сообщения');
    validateField('captcha', /.+/, 'Введите текст с изображения');

    // Если все обязательные поля заполнены, продолжаем сохранение в localStorage и т.д.
    if (document.getElementById('name').checkValidity() &&
        document.getElementById('email').checkValidity() &&
        document.getElementById('subject').checkValidity() &&
        document.getElementById('message').checkValidity() &&
        document.getElementById('captcha').checkValidity()) {
        saveToLocalStorage();
    }
}
function validateField(fieldName, regex, errorMessage) {
    var input = document.getElementById(fieldName);
    var errorSpan = document.getElementById(fieldName + 'Error');

    // Проверка на пустые поля
    if (input.value.trim() === '') {
        input.classList.add('error');
        errorSpan.innerText = 'Введите ' + getFieldNameInRussian(fieldName);
    } else if (!regex.test(input.value)) {
        input.classList.add('error');
        errorSpan.innerText = errorMessage;
    } else {
        input.classList.remove('error');
        errorSpan.innerText = '';
    }
}

function getFieldNameInRussian(fieldName) {
    switch (fieldName) {
        case 'name':
            return 'ваше имя';
        case 'email':
            return 'ваш Email адрес';
        case 'subject':
            return 'тему сообщения';
        case 'message':
            return 'текст сообщения';
        case 'captcha':
            return 'текст с изображения';
        default:
            return '';
    }
}